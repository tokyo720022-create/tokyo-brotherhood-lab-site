---
name: Bug report
about: Something isn't working in What's Next (web app or Android APK)
title: "Bug: "
labels: bug
---

## App version or APK filename
<!-- e.g. What Next? 2.1.1, or the APK file name and the upload date shown on the release list -->

## Device model
<!-- e.g. Pixel 7, Galaxy S23 (leave blank if you used the web app on a computer) -->

## Android version / browser
<!-- e.g. Android 14 (Settings > About phone), or the browser and version for the web app -->

## Description of the problem
<!-- What went wrong? Include the exact error message if there is one. -->

## Steps to reproduce
1. 
2. 
3. 

## Expected result
<!-- What did you expect to happen? -->

## Actual result
<!-- What happened instead? Screenshots help. Please hide private details first. -->
