---
name: Feedback or suggestion
about: Share an idea or tell us what could be better in What's Next
title: "Feedback: "
labels: enhancement
---

## Your feedback or suggestion
<!-- What would you like to see improved or added? -->

## Why it would help
<!-- Optional: how would you use it? -->
