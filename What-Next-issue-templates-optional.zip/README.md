# Optional issue templates for the What-Next repository

These two files belong in the **What-Next** repository (not the website repository):

    .github/ISSUE_TEMPLATE/bug_report.md
    .github/ISSUE_TEMPLATE/feedback.md

The What-Next repository has no issue templates today, so the website's "Report a bug" and
"Send feedback" links prefill the new-issue form themselves and work without these files.

If you add the templates, open `docs/assets/js/site-utils.js` in the website repository and set
`useIssueTemplates: true`. The links will then open the templates instead of building the form text.
Note: once templates exist, GitHub shows its template chooser for plain `/issues/new` links.
